public class Main {

    public static void main(String[] args) {

        System.out.println("===== ETAPA 2 - SIMPLE FACTORY =====");

        FabricaPainel fabrica = new FabricaPainel();

        Painel painelAluno = fabrica.criarPainel("ALUNO");
        painelAluno.exibir();

        System.out.println();

        Painel painelProfessor = fabrica.criarPainel("PROFESSOR");
        painelProfessor.exibir();

        System.out.println();

        Painel painelCoordenador = fabrica.criarPainel("COORDENADOR");
        painelCoordenador.exibir();

        System.out.println();
        System.out.println("===== ETAPA 3 - FACTORY METHOD =====");

        CriadorPainel criadorAluno = new CriadorPainelAluno();
        criadorAluno.exibirPainel();

        System.out.println();

        CriadorPainel criadorProfessor = new CriadorPainelProfessor();
        criadorProfessor.exibirPainel();

        System.out.println();

        CriadorPainel criadorCoordenador = new CriadorPainelCoordenador();
        criadorCoordenador.exibirPainel();

        System.out.println();
        System.out.println("===== ETAPA 4 - NOVO PERFIL =====");

        CriadorPainel criadorAdministrador = new CriadorPainelAdministrador();
        criadorAdministrador.exibirPainel();

        System.out.println();
        System.out.println("Todos os painéis foram criados e exibidos com sucesso.");
    }
}
