public class PainelCoordenador implements Painel {

    @Override
    public void exibir() {
        System.out.println("Painel do coordenador");
        System.out.println("Opções: acompanhar cursos, turmas e professores.");
    }
}
