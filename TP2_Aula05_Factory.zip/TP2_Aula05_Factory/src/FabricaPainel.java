public class FabricaPainel {

    public Painel criarPainel(String perfil) {
        if (perfil == null) {
            throw new IllegalArgumentException("Perfil não pode ser nulo.");
        }

        switch (perfil.toUpperCase()) {
            case "ALUNO":
                return new PainelAluno();

            case "PROFESSOR":
                return new PainelProfessor();

            case "COORDENADOR":
                return new PainelCoordenador();

            case "ADMINISTRADOR":
                return new PainelAdministrador();

            default:
                throw new IllegalArgumentException("Perfil não encontrado: " + perfil);
        }
    }
}
