public abstract class CriadorPainel {

    public abstract Painel criarPainel();

    public void exibirPainel() {
        Painel painel = criarPainel();
        painel.exibir();
    }
}
